package com.gieok.memory;

import android.Manifest;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.Locale;

public class MemoryWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAll(context, appWidgetManager, appWidgetIds);
    }

    public static void updateAll(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_memory);
            boolean active = RecordingService.isRecording();
            if (active) {
                long elapsed = System.currentTimeMillis() - RecordingService.getStartedAt();
                views.setTextViewText(R.id.widgetStatus, "🔴 " + format(elapsed) + "  기억 중");
                views.setTextViewText(R.id.widgetButton, "■ 종료");
                Intent stop = new Intent(context, RecordingService.class).setAction(RecordingService.ACTION_STOP);
                PendingIntent pi = PendingIntent.getService(context, 21, stop,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                views.setOnClickPendingIntent(R.id.widgetButton, pi);
            } else {
                views.setTextViewText(R.id.widgetStatus, "기억");
                views.setTextViewText(R.id.widgetButton, "🎙 기억하기");
                boolean permission = context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
                if (permission) {
                    Intent start = new Intent(context, RecordingService.class).setAction(RecordingService.ACTION_START);
                    PendingIntent pi = PendingIntent.getForegroundService(context, 22, start,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    views.setOnClickPendingIntent(R.id.widgetButton, pi);
                } else {
                    Intent open = new Intent(context, MainActivity.class).putExtra("request_record", true);
                    PendingIntent pi = PendingIntent.getActivity(context, 23, open,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                    views.setOnClickPendingIntent(R.id.widgetButton, pi);
                }
            }
            manager.updateAppWidget(id, views);
        }
    }

    private static String format(long ms) {
        long sec = Math.max(0, ms / 1000);
        return String.format(Locale.KOREA, "%02d:%02d", sec / 60, sec % 60);
    }
}
