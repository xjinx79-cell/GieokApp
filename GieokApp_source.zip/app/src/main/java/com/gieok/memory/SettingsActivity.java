package com.gieok.memory;

import android.app.Activity;
import android.os.Bundle;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        SecurePrefs prefs = new SecurePrefs(this);
        EditText key = findViewById(R.id.editApiKey);
        CheckBox keep = findViewById(R.id.checkKeepAudio);
        String existing = prefs.getApiKey();
        if (!existing.isEmpty()) key.setHint("저장된 API 키가 있습니다. 변경할 때만 입력하세요.");
        keep.setChecked(prefs.keepAudio());
        findViewById(R.id.btnSaveSettings).setOnClickListener(v -> {
            try {
                String value = key.getText().toString().trim();
                if (!value.isEmpty()) prefs.saveApiKey(value);
                prefs.setKeepAudio(keep.isChecked());
                Toast.makeText(this, "저장했습니다.", Toast.LENGTH_SHORT).show();
                finish();
            } catch (Exception e) {
                Toast.makeText(this, "설정 저장 실패: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
