package com.gieok.memory;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class AiClient {
    private final Context context;
    private final SecurePrefs prefs;

    public AiClient(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = new SecurePrefs(context);
    }

    public boolean configured() {
        return !prefs.getApiKey().trim().isEmpty();
    }

    public String transcribe(File audio) throws Exception {
        String apiKey = prefs.getApiKey();
        if (apiKey.isEmpty()) throw new IllegalStateException("API 키가 없습니다.");

        String boundary = "----Gieok" + UUID.randomUUID();
        HttpURLConnection conn = (HttpURLConnection) new URL("https://api.openai.com/v1/audio/transcriptions").openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        try (OutputStream out = conn.getOutputStream()) {
            writePart(out, boundary, "model", "gpt-4o-transcribe");
            writePart(out, boundary, "language", "ko");
            out.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
            out.write(("Content-Disposition: form-data; name=\"file\"; filename=\"memory.m4a\"\r\n").getBytes(StandardCharsets.UTF_8));
            out.write("Content-Type: audio/mp4\r\n\r\n".getBytes(StandardCharsets.UTF_8));
            try (FileInputStream in = new FileInputStream(audio)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            out.write("\r\n".getBytes(StandardCharsets.UTF_8));
            out.write(("--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
        }

        String response = readResponse(conn);
        JSONObject json = new JSONObject(response);
        return json.optString("text", "").trim();
    }

    private void writePart(OutputStream out, String boundary, String name, String value) throws Exception {
        out.write(("--" + boundary + "\r\n").getBytes(StandardCharsets.UTF_8));
        out.write(("Content-Disposition: form-data; name=\"" + name + "\"\r\n\r\n").getBytes(StandardCharsets.UTF_8));
        out.write((value + "\r\n").getBytes(StandardCharsets.UTF_8));
    }

    public List<MemoryItem> organize(String originalText, String source, String audioPath) throws Exception {
        String apiKey = prefs.getApiKey();
        if (apiKey.isEmpty()) throw new IllegalStateException("API 키가 없습니다.");

        String instruction = "당신은 개인 기억 정리기다. 사용자가 말한 원문을 보존하면서 의미상 독립된 기억으로 나눈다. " +
                "category는 반드시 '할 것','살 것','가볼 곳','기억','취향','아이디어','기타' 중 하나만 사용한다. " +
                "감정은 별도 category로 만들지 않는다. 사용자가 명확히 표현한 감정만 tags에 emotion:힘듦 같은 형태로 보조 기록한다. " +
                "의학적·심리적 진단은 절대 추론하지 않는다. '꼭 기억해' 같은 표현이 있으면 important=true. " +
                "사람/장소/물건/날짜를 tags에 짧게 넣는다. 확실하지 않은 해석은 needs_review=true로 한다. " +
                "summary는 사용자의 의미를 바꾸지 않는 짧은 한국어 문장으로 작성한다. " +
                "반드시 JSON만 반환한다. 형식: {\"items\":[{\"summary\":\"...\",\"category\":\"기억\",\"tags\":[\"...\"],\"important\":false,\"needs_review\":false}]}";

        JSONObject body = new JSONObject();
        body.put("model", "gpt-5-mini");
        JSONArray input = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", instruction);
        input.put(system);
        JSONObject user = new JSONObject();
        user.put("role", "user");
        user.put("content", originalText);
        input.put(user);
        body.put("input", input);

        HttpURLConnection conn = (HttpURLConnection) new URL("https://api.openai.com/v1/responses").openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try (OutputStream out = conn.getOutputStream()) {
            out.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        String response = readResponse(conn);
        String text = extractOutputText(new JSONObject(response));
        JSONObject result = new JSONObject(stripJsonFence(text));
        JSONArray items = result.optJSONArray("items");
        List<MemoryItem> out = new ArrayList<>();
        if (items != null) {
            for (int i = 0; i < items.length(); i++) {
                JSONObject j = items.getJSONObject(i);
                MemoryItem m = new MemoryItem();
                m.createdAt = System.currentTimeMillis();
                m.originalText = originalText;
                m.summary = j.optString("summary", originalText);
                m.category = normalizeCategory(j.optString("category", "기억"));
                JSONArray tagArray = j.optJSONArray("tags");
                m.tags = joinTags(tagArray);
                m.important = j.optBoolean("important", false);
                m.needsReview = j.optBoolean("needs_review", false);
                m.source = source;
                m.audioPath = audioPath;
                m.status = "완료";
                out.add(m);
            }
        }
        if (out.isEmpty()) {
            MemoryItem fallback = rawMemory(originalText, source, audioPath, "AI 결과 확인 필요");
            fallback.needsReview = true;
            out.add(fallback);
        }
        return out;
    }

    public String answerQuestion(String question, List<MemoryItem> memories) throws Exception {
        String apiKey = prefs.getApiKey();
        if (apiKey.isEmpty()) throw new IllegalStateException("API 키가 없습니다.");
        StringBuilder contextText = new StringBuilder();
        int count = 0;
        for (MemoryItem m : memories) {
            if (count++ >= 120) break;
            contextText.append("- ").append(m.category).append(" | ")
                    .append(m.summary == null ? m.originalText : m.summary)
                    .append(" | tags=").append(m.tags == null ? "" : m.tags).append("\n");
        }
        JSONObject body = new JSONObject();
        body.put("model", "gpt-5-mini");
        body.put("input", "다음은 사용자가 직접 저장한 기억 목록이다. 목록에 근거해서만 질문에 한국어로 간단명료하게 답해라. " +
                "없는 내용은 추측하지 말고 '저장된 기억에서 찾지 못했습니다'라고 답해라.\n\n기억:\n" + contextText + "\n질문: " + question);
        HttpURLConnection conn = (HttpURLConnection) new URL("https://api.openai.com/v1/responses").openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setConnectTimeout(30000);
        conn.setReadTimeout(120000);
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        try (OutputStream out = conn.getOutputStream()) {
            out.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        return extractOutputText(new JSONObject(readResponse(conn))).trim();
    }

    private String extractOutputText(JSONObject json) {
        String direct = json.optString("output_text", "");
        if (!direct.isEmpty()) return direct;
        JSONArray output = json.optJSONArray("output");
        if (output == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < output.length(); i++) {
            JSONObject item = output.optJSONObject(i);
            if (item == null) continue;
            JSONArray content = item.optJSONArray("content");
            if (content == null) continue;
            for (int j = 0; j < content.length(); j++) {
                JSONObject c = content.optJSONObject(j);
                if (c == null) continue;
                String t = c.optString("text", "");
                if (!t.isEmpty()) sb.append(t);
            }
        }
        return sb.toString();
    }

    private String stripJsonFence(String s) {
        String t = s.trim();
        if (t.startsWith("```")) {
            int firstNewline = t.indexOf('\n');
            int lastFence = t.lastIndexOf("```");
            if (firstNewline >= 0 && lastFence > firstNewline) t = t.substring(firstNewline + 1, lastFence).trim();
        }
        return t;
    }

    private String joinTags(JSONArray tags) {
        if (tags == null) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tags.length(); i++) {
            String tag = tags.optString(i, "").trim();
            if (tag.isEmpty()) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(tag);
        }
        return sb.toString();
    }

    private String normalizeCategory(String category) {
        String[] allowed = {"할 것", "살 것", "가볼 곳", "기억", "취향", "아이디어", "기타"};
        for (String a : allowed) if (a.equals(category)) return a;
        return "기억";
    }

    public static MemoryItem rawMemory(String text, String source, String audioPath, String status) {
        MemoryItem m = new MemoryItem();
        m.createdAt = System.currentTimeMillis();
        m.originalText = text;
        m.summary = text;
        m.category = "기억";
        m.tags = "";
        m.source = source;
        m.audioPath = audioPath;
        m.status = status;
        return m;
    }

    private String readResponse(HttpURLConnection conn) throws Exception {
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        if (stream == null) throw new IllegalStateException("HTTP " + code);
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        if (code < 200 || code >= 300) throw new IllegalStateException("OpenAI HTTP " + code + ": " + sb);
        return sb.toString();
    }
}
