package com.gieok.memory;

public class MemoryItem {
    public long id;
    public long createdAt;
    public String originalText;
    public String summary;
    public String category;
    public String tags;
    public boolean important;
    public boolean needsReview;
    public String source;
    public String audioPath;
    public String status;

    @Override
    public String toString() {
        String mark = important ? "★ " : "";
        String cat = category == null || category.isEmpty() ? "기억" : category;
        String body = summary == null || summary.isEmpty() ? originalText : summary;
        return mark + "[" + cat + "] " + (body == null ? "" : body);
    }
}
