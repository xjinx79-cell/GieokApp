package com.gieok.memory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class MemoryDb extends SQLiteOpenHelper {
    private static final String DB_NAME = "gieok.db";
    private static final int DB_VERSION = 1;

    public MemoryDb(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE memories (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "created_at INTEGER NOT NULL," +
                "original_text TEXT," +
                "summary TEXT," +
                "category TEXT," +
                "tags TEXT," +
                "important INTEGER DEFAULT 0," +
                "needs_review INTEGER DEFAULT 0," +
                "source TEXT," +
                "audio_path TEXT," +
                "status TEXT" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public long insert(MemoryItem item) {
        ContentValues v = new ContentValues();
        v.put("created_at", item.createdAt == 0 ? System.currentTimeMillis() : item.createdAt);
        v.put("original_text", item.originalText);
        v.put("summary", item.summary);
        v.put("category", item.category);
        v.put("tags", item.tags);
        v.put("important", item.important ? 1 : 0);
        v.put("needs_review", item.needsReview ? 1 : 0);
        v.put("source", item.source);
        v.put("audio_path", item.audioPath);
        v.put("status", item.status);
        return getWritableDatabase().insert("memories", null, v);
    }

    public List<MemoryItem> recent(int limit) {
        List<MemoryItem> out = new ArrayList<>();
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM memories ORDER BY created_at DESC LIMIT ?",
                new String[]{String.valueOf(limit)});
        try {
            while (c.moveToNext()) out.add(fromCursor(c));
        } finally {
            c.close();
        }
        return out;
    }

    public List<MemoryItem> searchLocal(String query, int limit) {
        List<MemoryItem> out = new ArrayList<>();
        String q = "%" + query + "%";
        Cursor c = getReadableDatabase().rawQuery(
                "SELECT * FROM memories WHERE original_text LIKE ? OR summary LIKE ? OR tags LIKE ? ORDER BY created_at DESC LIMIT ?",
                new String[]{q, q, q, String.valueOf(limit)});
        try {
            while (c.moveToNext()) out.add(fromCursor(c));
        } finally {
            c.close();
        }
        return out;
    }

    private MemoryItem fromCursor(Cursor c) {
        MemoryItem m = new MemoryItem();
        m.id = c.getLong(c.getColumnIndexOrThrow("id"));
        m.createdAt = c.getLong(c.getColumnIndexOrThrow("created_at"));
        m.originalText = c.getString(c.getColumnIndexOrThrow("original_text"));
        m.summary = c.getString(c.getColumnIndexOrThrow("summary"));
        m.category = c.getString(c.getColumnIndexOrThrow("category"));
        m.tags = c.getString(c.getColumnIndexOrThrow("tags"));
        m.important = c.getInt(c.getColumnIndexOrThrow("important")) == 1;
        m.needsReview = c.getInt(c.getColumnIndexOrThrow("needs_review")) == 1;
        m.source = c.getString(c.getColumnIndexOrThrow("source"));
        m.audioPath = c.getString(c.getColumnIndexOrThrow("audio_path"));
        m.status = c.getString(c.getColumnIndexOrThrow("status"));
        return m;
    }
}
