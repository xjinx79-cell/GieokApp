package com.gieok.memory;

import android.Manifest;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_AUDIO = 100;
    private static final int REQ_NOTIFICATIONS = 101;
    private Button btnRecord;
    private EditText editDirect;
    private ListView list;
    private MemoryDb db;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new MemoryDb(this);
        btnRecord = findViewById(R.id.btnRecord);
        editDirect = findViewById(R.id.editDirect);
        list = findViewById(R.id.listMemories);

        btnRecord.setOnClickListener(v -> toggleRecording());
        findViewById(R.id.btnSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnSearch).setOnClickListener(v -> startActivity(new Intent(this, SearchActivity.class)));
        findViewById(R.id.btnSaveText).setOnClickListener(v -> saveDirectText());

        requestNotificationPermissionIfNeeded();
        if (getIntent().getBooleanExtra("request_record", false)) ensureAudioPermission(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void toggleRecording() {
        if (RecordingService.isRecording()) {
            Intent stop = new Intent(this, RecordingService.class).setAction(RecordingService.ACTION_STOP);
            startService(stop);
            btnRecord.setText("🎙  기억하기");
            return;
        }
        ensureAudioPermission(true);
    }

    private void ensureAudioPermission(boolean startAfter) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (startAfter) startRecordingService();
        } else {
            getPreferences(MODE_PRIVATE).edit().putBoolean("start_after_permission", startAfter).apply();
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_AUDIO);
        }
    }

    private void startRecordingService() {
        Intent start = new Intent(this, RecordingService.class).setAction(RecordingService.ACTION_START);
        startForegroundService(start);
        btnRecord.setText("■  녹음 종료");
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_AUDIO) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            boolean start = getPreferences(MODE_PRIVATE).getBoolean("start_after_permission", false);
            if (granted && start) startRecordingService();
            updateWidgets();
        }
    }

    private void saveDirectText() {
        String text = editDirect.getText().toString().trim();
        if (text.isEmpty()) return;
        editDirect.setText("");
        AiClient ai = new AiClient(this);
        if (!ai.configured()) {
            MemoryItem m = AiClient.rawMemory(text, "text", null, "원문 저장");
            db.insert(m);
            Toast.makeText(this, "기억을 저장했습니다.", Toast.LENGTH_SHORT).show();
            refresh();
            return;
        }
        Toast.makeText(this, "AI가 정리 중입니다.", Toast.LENGTH_SHORT).show();
        executor.execute(() -> {
            try {
                List<MemoryItem> items = ai.organize(text, "text", null);
                for (MemoryItem m : items) db.insert(m);
                runOnUiThread(() -> {
                    Toast.makeText(this, "기억 " + items.size() + "개를 저장했습니다.", Toast.LENGTH_SHORT).show();
                    refresh();
                });
            } catch (Exception e) {
                MemoryItem raw = AiClient.rawMemory(text, "text", null, "AI 처리 실패");
                raw.needsReview = true;
                db.insert(raw);
                runOnUiThread(() -> {
                    Toast.makeText(this, "원문은 저장했습니다. AI 처리는 실패했습니다.", Toast.LENGTH_LONG).show();
                    refresh();
                });
            }
        });
    }

    private void refresh() {
        btnRecord.setText(RecordingService.isRecording() ? "■  녹음 종료" : "🎙  기억하기");
        List<MemoryItem> data = db.recent(50);
        List<String> rows = new ArrayList<>();
        for (MemoryItem m : data) {
            String extra = m.needsReview ? "  · 확인 필요" : "";
            rows.add(m.toString() + extra);
        }
        list.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows));
    }

    private void updateWidgets() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        int[] ids = manager.getAppWidgetIds(new ComponentName(this, MemoryWidgetProvider.class));
        MemoryWidgetProvider.updateAll(this, manager, ids);
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
