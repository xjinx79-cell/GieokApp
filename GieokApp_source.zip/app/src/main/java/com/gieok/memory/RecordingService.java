package com.gieok.memory;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.widget.RemoteViews;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class RecordingService extends Service {
    public static final String ACTION_START = "com.gieok.memory.START";
    public static final String ACTION_STOP = "com.gieok.memory.STOP";
    private static final String CHANNEL_RECORD = "recording";
    private static final String CHANNEL_WARNING = "recording_warning";
    private static final int NOTIFICATION_ID = 1001;
    private static final int WARNING_ID = 1002;
    private static volatile boolean recording = false;
    private static volatile long startedAt = 0L;

    private MediaRecorder recorder;
    private File outputFile;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private boolean warningSent = false;

    public static boolean isRecording() { return recording; }
    public static long getStartedAt() { return startedAt; }

    @Override
    public void onCreate() {
        super.onCreate();
        createChannels();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopRecording();
            return START_NOT_STICKY;
        }
        if (!recording) startRecording();
        return START_NOT_STICKY;
    }

    private void startRecording() {
        try {
            File dir = new File(getFilesDir(), "recordings");
            if (!dir.exists()) dir.mkdirs();
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.KOREA).format(new Date());
            outputFile = new File(dir, "memory_" + stamp + ".m4a");

            recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(96000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(outputFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();

            recording = true;
            startedAt = System.currentTimeMillis();
            warningSent = false;

            Notification notification = buildRecordingNotification(0);
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            updateWidget();
            handler.post(tick);
        } catch (Exception e) {
            recording = false;
            startedAt = 0L;
            stopSelf();
        }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!recording) return;
            long elapsed = System.currentTimeMillis() - startedAt;
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.notify(NOTIFICATION_ID, buildRecordingNotification(elapsed));
            updateWidget();
            if (!warningSent && elapsed >= 10 * 60 * 1000L) {
                warningSent = true;
                nm.notify(WARNING_ID, buildTenMinuteWarning());
            }
            handler.postDelayed(this, 1000);
        }
    };

    private void stopRecording() {
        if (!recording) {
            stopSelf();
            return;
        }
        recording = false;
        handler.removeCallbacks(tick);
        try { recorder.stop(); } catch (Exception ignored) { }
        try { recorder.release(); } catch (Exception ignored) { }
        recorder = null;
        startedAt = 0L;
        stopForeground(STOP_FOREGROUND_REMOVE);
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.cancel(WARNING_ID);
        updateWidget();

        final File finished = outputFile;
        outputFile = null;
        if (finished != null && finished.exists() && finished.length() > 0) {
            executor.execute(() -> processRecording(finished));
        }
        stopSelf();
    }

    private void processRecording(File audio) {
        MemoryDb db = new MemoryDb(getApplicationContext());
        AiClient ai = new AiClient(getApplicationContext());
        if (!ai.configured()) {
            MemoryItem pending = AiClient.rawMemory("음성 기록 — API 키 설정 후 AI 정리 가능", "voice", audio.getAbsolutePath(), "AI 처리 대기");
            db.insert(pending);
            notifyProcessed("음성 기록을 저장했습니다. API 키를 설정하면 AI 정리를 사용할 수 있습니다.");
            return;
        }
        try {
            String transcript = ai.transcribe(audio);
            if (transcript.isEmpty()) throw new IllegalStateException("전사 결과가 비어 있습니다.");
            List<MemoryItem> items = ai.organize(transcript, "voice", audio.getAbsolutePath());
            for (MemoryItem m : items) db.insert(m);
            if (!new SecurePrefs(getApplicationContext()).keepAudio()) {
                // Text and AI results are already persisted before deletion.
                audio.delete();
            }
            notifyProcessed("기억 " + items.size() + "개를 저장했습니다.");
        } catch (Exception e) {
            MemoryItem failed = AiClient.rawMemory("음성 기록 — AI 처리 실패", "voice", audio.getAbsolutePath(), "처리 실패: " + e.getMessage());
            failed.needsReview = true;
            db.insert(failed);
            notifyProcessed("음성은 보관했습니다. AI 처리는 다시 확인해 주세요.");
        }
    }

    private Notification buildRecordingNotification(long elapsed) {
        Intent stop = new Intent(this, RecordingService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 3, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new Notification.Builder(this, CHANNEL_RECORD)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentTitle("기억 녹음 중 · " + formatElapsed(elapsed))
                .setContentText("종료 버튼을 누를 때까지 계속 녹음합니다.")
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(new Notification.Action.Builder(null, "■ 녹음 종료", stopPi).build())
                .build();
    }

    private Notification buildTenMinuteWarning() {
        Intent stop = new Intent(this, RecordingService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 4, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_WARNING)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("녹음이 10분을 넘었습니다")
                .setContentText("계속 녹음 중입니다. 필요하면 종료해 주세요.")
                .setAutoCancel(true)
                .addAction(new Notification.Action.Builder(null, "■ 종료", stopPi).build())
                .build();
    }

    private void notifyProcessed(String text) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification n = new Notification.Builder(this, CHANNEL_RECORD)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("기억")
                .setContentText(text)
                .setAutoCancel(true)
                .build();
        nm.notify(1003, n);
    }

    private void createChannels() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel record = new NotificationChannel(CHANNEL_RECORD, "기억 녹음", NotificationManager.IMPORTANCE_LOW);
        record.setDescription("백그라운드 녹음 상태");
        nm.createNotificationChannel(record);
        NotificationChannel warning = new NotificationChannel(CHANNEL_WARNING, "10분 녹음 경고", NotificationManager.IMPORTANCE_HIGH);
        warning.setDescription("녹음이 10분을 넘을 때 알림");
        nm.createNotificationChannel(warning);
    }

    private String formatElapsed(long ms) {
        long sec = Math.max(0, ms / 1000);
        return String.format(Locale.KOREA, "%02d:%02d", sec / 60, sec % 60);
    }

    private void updateWidget() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        int[] ids = manager.getAppWidgetIds(new ComponentName(this, MemoryWidgetProvider.class));
        MemoryWidgetProvider.updateAll(this, manager, ids);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        executor.shutdown();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
