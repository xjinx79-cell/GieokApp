package com.gieok.memory;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SearchActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        EditText query = findViewById(R.id.editQuery);
        TextView answer = findViewById(R.id.textAnswer);
        MemoryDb db = new MemoryDb(this);
        AiClient ai = new AiClient(this);

        findViewById(R.id.btnAsk).setOnClickListener(v -> {
            String q = query.getText().toString().trim();
            if (q.isEmpty()) return;
            if (!ai.configured()) {
                List<MemoryItem> local = db.searchLocal(q, 30);
                if (local.isEmpty()) answer.setText("저장된 기억에서 찾지 못했습니다.\n\n자연어 AI 검색을 사용하려면 설정에서 OpenAI API 키를 입력하세요.");
                else {
                    StringBuilder sb = new StringBuilder();
                    for (MemoryItem m : local) sb.append("• ").append(m.toString()).append("\n");
                    answer.setText(sb.toString());
                }
                return;
            }
            answer.setText("기억을 찾는 중입니다…");
            executor.execute(() -> {
                try {
                    String result = ai.answerQuestion(q, db.recent(200));
                    runOnUiThread(() -> answer.setText(result));
                } catch (Exception e) {
                    runOnUiThread(() -> answer.setText("AI 검색에 실패했습니다.\n" + e.getMessage()));
                }
            });
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdown();
        super.onDestroy();
    }
}
